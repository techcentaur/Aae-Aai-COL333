#!/usr/bin/env bash

./main "$1" "$2"